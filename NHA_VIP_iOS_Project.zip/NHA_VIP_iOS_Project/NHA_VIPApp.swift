import SwiftUI

@main
struct NHAVIPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
