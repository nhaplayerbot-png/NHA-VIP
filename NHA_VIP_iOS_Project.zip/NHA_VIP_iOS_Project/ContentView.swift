import SwiftUI

struct ContentView: View {
    @State private var aimTrainer = false
    @State private var practiceTips = true
    @State private var soundEffects = false

    private let neonGreen = Color(red: 0.20, green: 0.95, blue: 0.42)

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.055, blue: 0.045).ignoresSafeArea()

            ScrollView {
                VStack(spacing: 22) {
                    VStack(spacing: 8) {
                        Text("NHA VIP")
                            .font(.system(size: 36, weight: .black, design: .rounded))
                            .foregroundStyle(neonGreen)
                        Text("AIM PRACTICE • TRAINING DEMO")
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tracking(2)
                            .foregroundStyle(.white.opacity(0.65))
                    }
                    .padding(.top, 32)

                    VStack(spacing: 14) {
                        Image(systemName: "scope")
                            .font(.system(size: 58, weight: .light))
                            .foregroundStyle(neonGreen)
                        Text("Practice Zone")
                            .font(.title2.bold())
                            .foregroundStyle(.white)
                        Text("A safe standalone practice demo. It does not connect to or change Free Fire.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white.opacity(0.68))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(24)
                    .background(Color.white.opacity(0.055))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(neonGreen.opacity(0.45), lineWidth: 1))
                    .clipShape(RoundedRectangle(cornerRadius: 20))

                    VStack(spacing: 12) {
                        toggleRow("Aim Trainer", detail: "Standalone practice mode", isOn: $aimTrainer)
                        toggleRow("Practice Tips", detail: "Show simple training reminders", isOn: $practiceTips)
                        toggleRow("Sound Effects", detail: "Demo setting only", isOn: $soundEffects)
                    }
                    .padding(18)
                    .background(Color.white.opacity(0.055))
                    .clipShape(RoundedRectangle(cornerRadius: 20))

                    if aimTrainer {
                        VStack(spacing: 12) {
                            Text("TARGET PRACTICE")
                                .font(.caption.bold())
                                .tracking(2)
                                .foregroundStyle(neonGreen)
                            Image(systemName: "circle.dotted")
                                .font(.system(size: 64))
                                .foregroundStyle(neonGreen)
                            Text("Tap targets in a future practice exercise.")
                                .font(.footnote)
                                .foregroundStyle(.white.opacity(0.7))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(20)
                        .background(Color.black.opacity(0.35))
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                    }

                    if practiceTips {
                        Text("TIP: Keep your aim steady and practice regularly.")
                            .font(.footnote)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(neonGreen.opacity(0.9))
                            .padding(.horizontal, 10)
                    }

                    Text("NHA VIP • DEMO BUILD")
                        .font(.caption2.monospaced())
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.35))
                        .padding(.bottom, 24)
                }
                .padding(.horizontal, 20)
            }
        }
        .preferredColorScheme(.dark)
    }

    @ViewBuilder
    private func toggleRow(_ title: String, detail: String, isOn: Binding<Bool>) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline).foregroundStyle(.white)
                Text(detail).font(.caption).foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            Toggle(title, isOn: isOn)
                .labelsHidden()
                .tint(neonGreen)
        }
        .padding(.vertical, 7)
    }
}
