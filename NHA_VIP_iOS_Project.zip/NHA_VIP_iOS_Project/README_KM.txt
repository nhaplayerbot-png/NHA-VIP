NHA VIP iOS Project (Demo)

នេះជាកូដប្រភព SwiftUI សម្រាប់កម្មវិធី Demo ពណ៌បៃតង NHA VIP មានប៊ូតុង ON/OFF។
វាជា standalone aim-practice demo ប៉ុណ្ណោះ មិនភ្ជាប់ទៅ Free Fire និងមិនមាន auto-aim/headshot cheat ទេ។

សំខាន់៖
- ឯកសារនេះមិនទាន់ជា IPA ទេ។
- ដើម្បីបង្កើត IPA ត្រូវ Build ជា iOS app ហើយ Sign ដោយ certificate/profile ដែលត្រឹមត្រូវ។
- ការបង្កើត IPA ពេញលេញត្រូវការឧបករណ៍ Build iOS ដែលគាំទ្រ (ជាទូទៅ Xcode លើ Mac ឬ cloud build service)។
- កុំផ្ញើ Apple ID password ឬ signing certificate ឯកជនទៅអ្នកដទៃ។
