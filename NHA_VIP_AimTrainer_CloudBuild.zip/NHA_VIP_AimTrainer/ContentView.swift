import SwiftUI

struct ContentView: View {
    @State private var target = CGPoint(x: 0.5, y: 0.4)
    @State private var score = 0
    @State private var shots = 0

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(red: 0.04, green: 0.08, blue: 0.12).ignoresSafeArea()
                VStack(spacing: 14) {
                    Text("NHA VIP")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(.green)
                    Text("AIM TRAINER • DEMO")
                        .font(.caption.bold())
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.7))
                    HStack {
                        stat("SCORE", value: score)
                        stat("TAPS", value: shots)
                    }
                    .padding(.horizontal, 24)

                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white.opacity(0.05))
                            .overlay(RoundedRectangle(cornerRadius: 20).stroke(.green.opacity(0.5), lineWidth: 1))
                        Circle()
                            .stroke(.red, lineWidth: 4)
                            .frame(width: 58, height: 58)
                            .overlay(Circle().stroke(.white, lineWidth: 1).frame(width: 24, height: 24))
                            .position(x: target.x * geo.size.width, y: target.y * geo.size.height)
                            .contentShape(Circle())
                            .onTapGesture {
                                score += 1
                                shots += 1
                                moveTarget(in: geo.size)
                            }
                            .accessibilityLabel("Target")
                    }
                    .frame(height: geo.size.height * 0.58)
                    .padding(.horizontal, 18)
                    Text("Tap the red target to practice your aim.")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.75))
                    Button("MOVE TARGET") {
                        shots += 1
                        moveTarget(in: geo.size)
                    }
                    .font(.headline)
                    .foregroundStyle(.black)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 14)
                    .background(.green, in: Capsule())
                    Button("RESET SCORE") {
                        score = 0
                        shots = 0
                    }
                    .font(.caption.bold())
                    .foregroundStyle(.white.opacity(0.8))
                    Spacer(minLength: 4)
                }
                .padding(.top, 20)
            }
            .onAppear { moveTarget(in: geo.size) }
        }
    }

    private func stat(_ title: String, value: Int) -> some View {
        VStack(spacing: 4) {
            Text(title).font(.caption2.bold()).foregroundStyle(.white.opacity(0.6))
            Text("\(value)").font(.title2.bold()).foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity)
        .padding(12)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))
    }

    private func moveTarget(in size: CGSize) {
        target = CGPoint(
            x: CGFloat.random(in: 0.18...0.82),
            y: CGFloat.random(in: 0.20...0.78)
        )
    }
}
