import SwiftUI

@main
struct NHAVIPAimTrainerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
