NHA VIP Aim Trainer (Demo)
==========================

នេះជាកម្មវិធីហាត់តម្រង់គោលដៅដាច់ដោយឡែកពី Free Fire។
វាមិនភ្ជាប់ទៅ Free Fire មិនមាន aimbot និងមិនបាញ់ដោយស្វ័យប្រវត្តិទេ។

ការបើកលើ Mac:
1. បើក NHA_VIP_AimTrainer.xcodeproj ក្នុង Xcode។
2. ជ្រើស Team/Signing របស់អ្នក ប្រសិនបើចង់ដំឡើងលើ iPhone។
3. Build និង Run។

ចំណាំ:
- GitHub Actions workflow ក្នុង ZIP នេះបង្កើត iOS Simulator build ជា artifact សម្រាប់សាកល្បង។
- វាមិនបង្កើត IPA សម្រាប់ iPhone ពិតដោយស្វ័យប្រវត្តិទេ។
- ការបង្កើត IPA ដែលអាចដំឡើងបាន ត្រូវការ signing/provisioning ដែលត្រឹមត្រូវ។
